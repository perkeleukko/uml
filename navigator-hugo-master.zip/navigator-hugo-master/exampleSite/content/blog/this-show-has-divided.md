---
title: "This Show Has Divided"
date: 2018-07-08T12:18:46+06:00
image: images/blog/post-3.jpg
author: Theon Greyjoy
---

### Chatting with the ancestors

I always say my thanks to my ancestors and talk with them, with my guides. I talk to them about my day, what I want, what they need of me. I give my thanks to them for the day, even if I had a bad day. I let them know, ‘Thank you for making sure I ain’t die today, I survived through the fuck shit.It’s a big comfort to me to have that open line of communication because so many of my spirit guides are people who I knew in this lifetime who passed on, one being my father, one being my abuelita. It’s comforting to know even though they’re not here physically to do that anymore, they do it from the other side, for the ones I knew in this lifetime and the ones I didn’t. I’m able to say to myself, “Yo, I feel fucked up right now, but y’all always got me.” I know I’m fortunate to have that.

It’s a big comfort to me to have that open line of communication because so many of my spirit guides are people who I knew in this lifetime who passed on, one being my father, one being my abuelita. It’s comforting to know even though they’re not here physically to do that anymore, they do it from the other side, for the ones I knew in this lifetime and the ones I didn’t. I’m able to say to myself, “Yo, I feel fucked up right now, but y’all always got me.” I know I’m fortunate to have that.

It’s comforting to know even though they’re not here physically to do that anymore, they do it from the other side, for the ones I knew in this lifetime and the ones I didn’t. I’m able to say to myself, “Yo, I feel fucked up right now, but y’all always got me.” I know I’m fortunate to have that.